package server;

import javax.xml.ws.Endpoint;

import main.RechteckService;

public class Server {

	/**
	    * @param args
	    */
	public static void main(String[] args) {
		
		 //http://192.168.2.103:9202/rechteck/RechteckWebService?wsdl
	      Endpoint.publish("http://192.168.2.103:9202/rechteck", new RechteckService());      
	      System.out.println("AxxG-RechteckWebService-Server ready!");

	}

}
